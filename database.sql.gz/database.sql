-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: suivi_nash
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activites_physiques`
--

DROP TABLE IF EXISTS `activites_physiques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activites_physiques` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type_activite` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `duree_minutes` int NOT NULL,
  `calories_depensees` int NOT NULL,
  `date_heure` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`date_heure`),
  KEY `idx_activites_user_date` (`user_id`,`date_heure`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activites_physiques`
--

LOCK TABLES `activites_physiques` WRITE;
/*!40000 ALTER TABLE `activites_physiques` DISABLE KEYS */;
INSERT INTO `activites_physiques` VALUES (1,1,'marche',30,150,'2025-11-30 20:22:59'),(2,1,'course',60,600,'2025-11-30 20:23:07'),(3,2,'marche',60,480,'2025-11-30 20:23:39'),(4,2,'musculation',35,210,'2025-11-30 20:23:49');
/*!40000 ALTER TABLE `activites_physiques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aliments`
--

DROP TABLE IF EXISTS `aliments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aliments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int DEFAULT NULL,
  `calories_100g` float DEFAULT NULL,
  `proteines_100g` float DEFAULT NULL,
  `glucides_100g` float DEFAULT NULL,
  `sucres_100g` float DEFAULT NULL,
  `lipides_100g` float DEFAULT NULL,
  `acides_gras_satures_100g` float DEFAULT NULL,
  `fibres_100g` float DEFAULT NULL,
  `sodium_100g` float DEFAULT NULL,
  `nutriscore` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `openfoodfacts_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autres_infos` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_openfoodfacts` (`openfoodfacts_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `aliments_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aliments`
--

LOCK TABLES `aliments` WRITE;
/*!40000 ALTER TABLE `aliments` DISABLE KEYS */;
INSERT INTO `aliments` VALUES (7,'Capsule Chocolat x16 compatible DG',NULL,50,1.5,6.6,4.9,1.7,1.1,1,0.08,NULL,'3250392793012','/images/foods/3250392793012.jpg','{\"marque\": \"Planteur des tropiques\", \"source\": \"openfoodfacts\", \"image_url\": \"https://images.openfoodfacts.org/images/products/325/039/279/3012/front_fr.28.400.jpg\", \"code_barre\": \"3250392793012\"}'),(45,'Pepsi Z??ro Sleek 33 cl',NULL,0.4,0,0,0,0,0,0,0.01,NULL,'3168930159742','/images/foods/3168930159742.jpg','{\"marque\": \"Diet pepsi, Pepsi zero, Pepsico\", \"source\": \"openfoodfacts\", \"image_url\": \"https://images.openfoodfacts.org/images/products/316/893/015/9742/front_fr.54.400.jpg\", \"code_barre\": \"3168930159742\"}'),(47,'',NULL,373,5.6,79,69,2.2,1.4,6.7,0.06,NULL,'3700278400881','/images/foods/3700278400881.jpg','{\"marque\": \"Banania\", \"source\": \"openfoodfacts\", \"image_url\": \"https://images.openfoodfacts.org/images/products/370/027/840/0881/front_fr.74.400.jpg\", \"code_barre\": \"3700278400881\"}'),(60,'Blanc de poulet -25% sel',NULL,109,21,0.8,0.8,2.4,0.6,0,1.28,NULL,'4056489276739','/images/foods/4056489276739.jpg','{\"marque\": \"Lidl, Saint Alby\", \"source\": \"openfoodfacts\", \"image_url\": \"https://images.openfoodfacts.org/images/products/405/648/927/6739/front_fr.20.400.jpg\", \"code_barre\": \"4056489276739\"}'),(61,'Tartinable - Poulet nature',NULL,298,10,3.8,2.9,27,2.6,0,1.6,NULL,'26052632','/images/foods/26052632.jpg','{\"marque\": \"Delicato\", \"source\": \"openfoodfacts\", \"image_url\": \"https://images.openfoodfacts.org/images/products/000/002/605/2632/front_fr.61.400.jpg\", \"code_barre\": \"26052632\"}'),(63,'briochettes aux p??pites de chocolat au lait',NULL,354,7.8,52,18.7,12.3,4.2,2.2,1,NULL,'4056489257608','/images/foods/4056489257608.jpg','{\"marque\": \"ma??tre Jean Pierre\", \"source\": \"openfoodfacts\", \"image_url\": \"https://images.openfoodfacts.org/images/products/405/648/925/7608/front_fr.43.400.jpg\", \"code_barre\": \"4056489257608\"}');
/*!40000 ALTER TABLE `aliments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consommation_eau`
--

DROP TABLE IF EXISTS `consommation_eau`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consommation_eau` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `quantite_ml` int NOT NULL,
  `date_heure` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_consommation_eau_date_heure` (`date_heure`),
  KEY `idx_eau_user_date` (`user_id`,`date_heure`),
  CONSTRAINT `consommation_eau_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consommation_eau`
--

LOCK TABLES `consommation_eau` WRITE;
/*!40000 ALTER TABLE `consommation_eau` DISABLE KEYS */;
INSERT INTO `consommation_eau` VALUES (1,2,250,'2025-11-28 14:32:23'),(7,2,250,'2025-11-28 17:44:50'),(8,2,250,'2025-11-28 20:18:12'),(12,2,200,'2025-11-28 10:35:17'),(15,2,200,'2025-11-28 10:35:53'),(18,2,200,'2025-11-28 10:35:59'),(21,2,200,'2025-11-28 10:36:07'),(22,2,250,'2025-11-29 11:08:42'),(23,2,250,'2025-11-29 20:54:04'),(24,2,330,'2025-11-29 20:54:06'),(25,2,330,'2025-11-29 20:54:09'),(30,2,250,'2025-11-30 19:38:21'),(32,2,250,'2025-12-01 07:18:31'),(33,2,250,'2025-12-01 10:20:54'),(34,2,250,'2025-12-01 13:19:33'),(35,2,250,'2025-12-01 18:07:18'),(40,2,250,'2025-12-02 06:57:55'),(48,2,250,'2025-12-02 11:10:52'),(49,2,250,'2025-12-02 12:46:35'),(56,2,250,'2025-12-02 17:43:28');
/*!40000 ALTER TABLE `consommation_eau` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historique_mesures`
--

DROP TABLE IF EXISTS `historique_mesures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historique_mesures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `date_mesure` date NOT NULL,
  `poids` decimal(5,2) NOT NULL COMMENT 'Weight in kg',
  `imc` decimal(4,2) NOT NULL COMMENT 'BMI calculated',
  `taille` decimal(5,2) NOT NULL COMMENT 'Height in cm (for context)',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_date` (`user_id`,`date_mesure`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_historique_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Historical weight and BMI measurements for user trend analysis';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historique_mesures`
--

LOCK TABLES `historique_mesures` WRITE;
/*!40000 ALTER TABLE `historique_mesures` DISABLE KEYS */;
INSERT INTO `historique_mesures` VALUES (2,2,'2025-12-01',86.40,28.20,175.00,'2025-12-01 12:28:53','2025-12-01 12:28:53'),(7,2,'2025-12-01',86.00,28.10,175.00,'2025-12-01 14:09:23','2025-12-01 14:09:23'),(9,2,'2025-12-01',86.00,28.10,175.00,'2025-12-01 15:54:41','2025-12-01 15:54:41'),(11,2,'2025-12-02',86.00,28.10,175.00,'2025-12-02 11:30:16','2025-12-02 11:30:16'),(12,2,'2025-12-04',86.00,28.10,175.00,'2025-12-04 19:16:04','2025-12-04 19:16:04'),(13,2,'2025-12-04',86.00,28.10,175.00,'2025-12-04 19:16:09','2025-12-04 19:16:09'),(14,2,'2025-12-07',87.40,28.50,175.00,'2025-12-07 07:19:32','2025-12-07 07:19:32');
/*!40000 ALTER TABLE `historique_mesures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicaments`
--

DROP TABLE IF EXISTS `medicaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicaments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `dose` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('regulier','ponctuel') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'regulier',
  `frequence` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heures_prise` json DEFAULT NULL,
  `actif` tinyint(1) DEFAULT '1',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicaments`
--

LOCK TABLES `medicaments` WRITE;
/*!40000 ALTER TABLE `medicaments` DISABLE KEYS */;
INSERT INTO `medicaments` VALUES (2,'Bisoprolol','1Comprim?? de 5MG','regulier','2x par jour.','[\"matin\", \"soir\"]',1,'','2025-11-30 14:32:33','2025-11-30 14:34:19'),(4,'Sifrol','1 + 1/2 comprim?? le soir','regulier','1x','[\"soir\"]',1,'','2025-11-30 14:38:53','2025-11-30 14:38:53'),(9,'Tradonal retard 50','1 comprim?? ','ponctuel','2x par jour toute les 12heures minimum','[\"matin\", \"soir\"]',1,'','2025-11-30 18:36:13','2025-11-30 18:36:13');
/*!40000 ALTER TABLE `medicaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objectifs_nutrition`
--

DROP TABLE IF EXISTS `objectifs_nutrition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `objectifs_nutrition` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `calories_perte` float NOT NULL,
  `sucres_max` float NOT NULL,
  `graisses_sat_max` float NOT NULL,
  `proteines_min` float NOT NULL,
  `proteines_max` float NOT NULL,
  `fibres_min` float NOT NULL,
  `fibres_max` float NOT NULL,
  `sodium_max` float NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `taille` float NOT NULL DEFAULT '0',
  `poids` float NOT NULL DEFAULT '0',
  `annee` int NOT NULL DEFAULT '0',
  `sexe` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `activite` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `imc` float NOT NULL DEFAULT '0',
  `objectif` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'perte',
  `glucides` float NOT NULL DEFAULT '0',
  `graisses_insaturees` float NOT NULL DEFAULT '0',
  `date_debut` date NOT NULL DEFAULT (curdate()),
  `date_fin` date DEFAULT NULL,
  `actif` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_objectifs_actifs` (`user_id`,`actif`,`date_debut` DESC)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objectifs_nutrition`
--

LOCK TABLES `objectifs_nutrition` WRITE;
/*!40000 ALTER TABLE `objectifs_nutrition` DISABLE KEYS */;
INSERT INTO `objectifs_nutrition` VALUES (31,2,1784,50,30.7,68.8,86,25,30,5,'2025-12-01 15:09:23',175,86,1990,'homme','modere',28.1,'perte',0,0,'2025-12-01','2025-12-01',0),(32,2,1784,50,30.7,68.8,86,25,30,5,'2025-12-01 16:54:41',175,86,1990,'homme','sedentaire',28.1,'perte',0,0,'2025-12-01','2025-12-02',0),(33,2,1749,50,23.8,68.8,86,25,30,5,'2025-12-02 12:30:16',175,86,1983,'homme','sedentaire',28.1,'perte',0,0,'2025-12-02','2025-12-04',0),(34,2,1754,88,53,69,86,25,30,5,'2025-12-04 19:16:04',175,86,1984,'homme','sedentaire',28.1,'perte',0,0,'2025-12-04','2025-12-04',0),(35,2,1749,87,52,69,86,24,30,5,'2025-12-04 19:16:09',175,86,1983,'homme','sedentaire',28.1,'perte',0,0,'2025-12-04','2025-12-07',0),(36,2,1763,88,53,70,87,25,30,5,'2025-12-07 07:19:32',175,87.4,1983,'homme','sedentaire',28.5,'perte',0,0,'2025-12-07',NULL,1);
/*!40000 ALTER TABLE `objectifs_nutrition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prises_medicaments`
--

DROP TABLE IF EXISTS `prises_medicaments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prises_medicaments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `medicament_id` int NOT NULL,
  `date` date NOT NULL,
  `periode` enum('matin','midi','soir','nuit') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('pris','non') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'non',
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_prise` (`medicament_id`,`date`,`periode`),
  CONSTRAINT `prises_medicaments_ibfk_1` FOREIGN KEY (`medicament_id`) REFERENCES `medicaments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prises_medicaments`
--

LOCK TABLES `prises_medicaments` WRITE;
/*!40000 ALTER TABLE `prises_medicaments` DISABLE KEYS */;
INSERT INTO `prises_medicaments` VALUES (2,2,'2025-11-30','matin','pris','2025-11-30 14:37:36'),(6,2,'2025-11-30','soir','pris','2025-11-30 15:27:38'),(8,9,'2025-11-30','matin','pris','2025-11-30 18:36:16'),(9,4,'2025-11-30','soir','pris','2025-11-30 19:27:07'),(10,9,'2025-11-30','soir','pris','2025-12-01 04:09:58'),(11,2,'2025-12-01','matin','pris','2025-12-01 07:02:48'),(12,9,'2025-12-01','matin','pris','2025-12-01 07:02:52'),(13,9,'2025-12-01','soir','pris','2025-12-02 05:48:18'),(14,4,'2025-12-01','soir','pris','2025-12-02 05:48:19'),(15,2,'2025-12-01','soir','pris','2025-12-02 05:48:21'),(16,2,'2025-12-02','matin','pris','2025-12-02 05:48:28'),(17,9,'2025-12-02','matin','pris','2025-12-02 05:48:34'),(18,2,'2025-12-04','matin','pris','2025-12-04 17:09:55'),(19,9,'2025-12-04','matin','pris','2025-12-04 17:09:56'),(20,2,'2025-12-04','soir','pris','2025-12-04 17:09:59');
/*!40000 ALTER TABLE `prises_medicaments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prenom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `sexe` enum('H','F','Autre') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taille_cm` float DEFAULT NULL,
  `poids_kg` float DEFAULT NULL,
  `imc` float DEFAULT NULL,
  `proteines` float DEFAULT NULL,
  `glucides` float DEFAULT NULL,
  `lipides` float DEFAULT NULL,
  `autres_macros` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repas`
--

DROP TABLE IF EXISTS `repas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type_repas` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'repas',
  `date_heure` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `idx_repas_user_date` (`user_id`,`date_heure`),
  KEY `idx_repas_user_type_date` (`user_id`,`type_repas`,`date_heure`),
  CONSTRAINT `repas_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repas`
--

LOCK TABLES `repas` WRITE;
/*!40000 ALTER TABLE `repas` DISABLE KEYS */;
INSERT INTO `repas` VALUES (8,2,'dejeuner','2025-11-29 00:00:00'),(12,2,'dejeuner','2025-11-30 00:00:00'),(10,2,'diner','2025-11-29 00:00:00'),(9,2,'en-cas','2025-11-29 17:50:13'),(13,2,'gouter','2025-11-30 00:00:00'),(17,2,'gouter','2025-12-01 15:22:18'),(21,2,'gouter','2025-12-04 18:35:41'),(2,2,'petit-dejeuner','2025-11-28 16:07:06'),(5,2,'petit-dejeuner','2025-11-29 00:00:00'),(15,2,'petit-dejeuner','2025-11-30 00:00:00'),(16,2,'petit-dejeuner','2025-12-01 11:16:14'),(18,2,'petit-dejeuner','2025-12-02 06:49:28'),(19,2,'petit-dejeuner','2025-12-03 08:51:27'),(20,2,'petit-dejeuner','2025-12-04 16:32:16'),(22,2,'petit-dejeuner','2025-12-07 07:20:15'),(11,2,'repas','2025-11-29 00:00:00'),(14,2,'repas','2025-11-30 00:00:00');
/*!40000 ALTER TABLE `repas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repas_aliments`
--

DROP TABLE IF EXISTS `repas_aliments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repas_aliments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `repas_id` int NOT NULL,
  `aliment_id` int NOT NULL,
  `quantite_grammes` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `repas_id` (`repas_id`),
  KEY `aliment_id` (`aliment_id`),
  KEY `idx_repas_aliments_repas` (`repas_id`),
  KEY `idx_repas_aliments_aliment` (`aliment_id`),
  CONSTRAINT `repas_aliments_ibfk_1` FOREIGN KEY (`repas_id`) REFERENCES `repas` (`id`),
  CONSTRAINT `repas_aliments_ibfk_2` FOREIGN KEY (`aliment_id`) REFERENCES `aliments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repas_aliments`
--

LOCK TABLES `repas_aliments` WRITE;
/*!40000 ALTER TABLE `repas_aliments` DISABLE KEYS */;
INSERT INTO `repas_aliments` VALUES (8,2,7,150),(19,5,45,100),(26,8,7,112),(27,9,7,32),(28,12,47,30),(31,15,7,89),(38,16,61,100),(39,17,63,80),(40,18,47,20),(41,19,7,12),(42,20,47,12),(43,21,45,100),(44,22,7,17);
/*!40000 ALTER TABLE `repas_aliments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_config`
--

DROP TABLE IF EXISTS `user_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_config` (
  `user_id` int NOT NULL,
  `config_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`,`config_key`),
  KEY `idx_user_config_user_id` (`user_id`),
  CONSTRAINT `fk_user_config_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_config`
--

LOCK TABLES `user_config` WRITE;
/*!40000 ALTER TABLE `user_config` DISABLE KEYS */;
INSERT INTO `user_config` VALUES (2,'eau_objectif_litre','2'),(2,'imc_seuil_normal','25'),(2,'imc_seuil_sous_poids','18.5'),(2,'imc_seuil_surpoids','30'),(2,'lipides_max_g','22'),(2,'notify_hydration_enabled','1'),(2,'notify_quiet_end_hour','8'),(2,'notify_quiet_start_hour','22'),(2,'sucres_max_g','50');
/*!40000 ALTER TABLE `user_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mot_de_passe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_inscription` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'jim','jimdonne1609@gmail.com','$2y$10$FIfXPyf8/yBK9xupwrlBpOt0r2FV3kWsIrr6TG7kyYn0emEEwTh3a','2025-11-27 18:34:42'),(3,'GrokTest','test@grok.fr','$2y$10$59Q6RpgBmYg2HnHorznp9e0HJPeLZ7p.1dCJdGgckXuYFeQv2svPm','2025-12-08 08:40:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `walk_objectives`
--

DROP TABLE IF EXISTS `walk_objectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `walk_objectives` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `km_per_day` decimal(4,2) NOT NULL DEFAULT '5.00' COMMENT 'Objectif km par jour',
  `days_per_week` int NOT NULL DEFAULT '4' COMMENT 'Nombre de jours par semaine',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `walk_objectives_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `walk_objectives`
--

LOCK TABLES `walk_objectives` WRITE;
/*!40000 ALTER TABLE `walk_objectives` DISABLE KEYS */;
INSERT INTO `walk_objectives` VALUES (1,2,5.00,4,'2025-12-05 11:06:01','2025-12-05 11:06:01');
/*!40000 ALTER TABLE `walk_objectives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `walk_routes`
--

DROP TABLE IF EXISTS `walk_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `walk_routes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nom du parcours ex: Tour du lac',
  `distance_km` decimal(5,2) NOT NULL,
  `route_points` json NOT NULL COMMENT 'Array de {lat, lng} pour le trac??',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_routes_user` (`user_id`),
  CONSTRAINT `walk_routes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `walk_routes`
--

LOCK TABLES `walk_routes` WRITE;
/*!40000 ALTER TABLE `walk_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `walk_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `walks`
--

DROP TABLE IF EXISTS `walks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `walks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `walk_type` enum('marche','marche_rapide') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'marche',
  `distance_km` decimal(5,2) NOT NULL,
  `duration_minutes` int NOT NULL,
  `calories_burned` int DEFAULT NULL,
  `route_points` json DEFAULT NULL COMMENT 'Array de {lat, lng} pour le trac?? sur carte',
  `note` text COLLATE utf8mb4_unicode_ci,
  `walk_date` date NOT NULL,
  `start_time` time DEFAULT NULL COMMENT 'Heure de d??part de la marche',
  `end_time` time DEFAULT NULL COMMENT 'Heure d''arriv??e de la marche',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_walks_user_date` (`user_id`,`walk_date`),
  KEY `idx_walks_date` (`walk_date`),
  CONSTRAINT `walks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `walks`
--

LOCK TABLES `walks` WRITE;
/*!40000 ALTER TABLE `walks` DISABLE KEYS */;
/*!40000 ALTER TABLE `walks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-09 19:53:49
